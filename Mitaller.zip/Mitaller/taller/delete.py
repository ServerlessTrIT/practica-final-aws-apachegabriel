import json


def handler(event, context):
    pieza = json.loads(event['body'])
    key = {
        "serie": pieza['serie']
    }
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('TallerTable')
    result = table.delete_item(Key=key) 
    body = {
        "message": "delete",
        "input": pieza
    } 
    delete 
    response = {
        "statusCode": result['ResponeMetadata']['HTTPStatusCode'],
        "body": json.dumps(body)
    }

    return response

    # Use this code if you don't use the http event with the LAMBDA-PROXY
    # integration
    """
    return {
        "message": "Go Serverless v1.0! Your function executed successfully!",
        "event": event
    }
    """
