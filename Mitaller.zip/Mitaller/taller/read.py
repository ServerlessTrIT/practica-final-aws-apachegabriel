import json


def handler(event, context):
    if event ['pathParameters'] is None:
        message = "Lista de piezas"
    else:
        message = "Pieza "+str(event['pathParameters']['id'])
    body = {
        "message": message
    }

    response = {
        "statusCode": 200,
        "body": json.dumps(body)
    }

    return response

    # Use this code if you don't use the http event with the LAMBDA-PROXY
    # integration
    """
    return {
        "message": "Go Serverless v1.0! Your function executed successfully!",
        "event": event
    }
    """
