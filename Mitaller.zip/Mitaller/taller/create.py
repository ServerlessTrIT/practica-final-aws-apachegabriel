import json


def handler(event, context):
    taller = json.loads(event['body'])
    body = {
        "message": "Create",
        "input": taller
    }

    response = {
        "statusCode": 200,
        "body": json.dumps(body)
    }

    return response