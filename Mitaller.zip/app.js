var books = [];

/***********************************
               API
************************************/

const API_KEY="QoYFM7w3Hs2HmVFrGyq4sOp2nEXWT2k1QFYICN55"
const API_URL = "https://q9uifwghg1.execute-api.eu-central-1.amazonaws.com/DEV";
const API_LOGIN = API_URL+"login";
const API_SIGNUP = API_URL+"signup";
const API_CONFIRMSIGNUP = API_URL+"confirmsignup";
const API_TALLER = API_URL+"taller";

/* USERS */
function signup(event){
  console.log("signup");
  event.preventDefault();
  $.ajax({
    url: API_SIGNUP,
    method: "POST",
    dataType : "json",
    headers:{
      "x-api-key": API_KEY
    },
    data: JSON.stringify({
      "username":$("input[id='username']").val(),
      "password":$("input[id='password']").val()
    })
  }).done(function(resp){
    //$("div[id='msg']").text(resp.message);
    goTo('/confirmsignup');
  }).fail(function(msg){
    //$("div[id='msg']").text(JSON.parse(error.responseText).message);
    $("div[id='msg']").text("Se ha producido un error");
  });
  return true;
}

function confirmSignup(){
  console.log("confirmsignup");
  event.preventDefault();
  $.ajax({
    url: API_CONFIRMSIGNUP,
    method: "POST",
    dataType : "json",
    headers:{
      "x-api-key": API_KEY
    },
    data: JSON.stringify({
      "username":$("input[id='username']").val(),
      "code":$("input[id='code']").val()
    })
  }).done(function(resp){
    $("div[id='msg']").text(resp.message);
  }).fail(function(msg){
    //$("div[id='msg']").text(JSON.parse(error.responseText).message);
    $("div[id='msg']").text("Se ha producido un error");
  });
  return false;
}

function login(event){
  console.log("login");
  event.preventDefault();
  
  $.ajax({
    url: API_LOGIN,
    method: "POST",
    dataType : "json",
    headers:{
      "x-api-key": API_KEY
    },
    data: JSON.stringify({
      "username":$("input[id='username']").val(),
      "password":$("input[id='password']").val()
    })
  }).done(function(resp){
    localStorage.setItem('token', resp.token);
    goTo("/");
  }).fail(function(error){
    //$("div[id='msg']").text(JSON.parse(error.responseText).message);
    $("div[id='msg']").text("Credenciales incorrectas");
  });
  
  return false;
}

/* BOOKS */

function getPiezas(){
  console.log("getPiezas");
  //event.preventDefault();
  
  $.ajax({
    url: API_TALLER,
    method: "GET",
    headers:{
      "x-api-key": API_KEY,
      "Authorization":"Bearer "+localStorage.getItem('token')
    }
  }).done(function(resp){
    books=resp.items;
    goTo("/taller");
  }).fail(function(error){
    //console.log(JSON.stringify(error));
    localStorage.removeItem('token');
    goTo("/");
  });
  
  return false;
}

function putPieza(){
  console.log("putPieza");
  event.preventDefault();
  
  $.ajax({
    url: API_TALLER
    method: "POST",
    headers:{
      "x-api-key": API_KEY,
      "Authorization":"Bearer "+localStorage.getItem('token')
    },
    data: JSON.stringify({
      "isbn":$("input[id='isbn']").val(),
      "title":$("input[id='title']").val()
    })
  }).done(function(resp){
    getBooks(); //actualizar listado de libros
  }).fail(function(error){
    //console.log(JSON.stringify(error));
    localStorage.removeItem('token');
    goTo("/");
  });
  
  return false;
}

function deletePieza(event){
  console.log("deletePieza");
  event.preventDefault();
  isbn = $(this).attr('id').split("_")[1];
  console.log(isbn);
  $.ajax({
    url: API_TALLER
    method: "DELETE",
    headers:{
      "x-api-key": API_KEY,
      "Authorization":"Bearer "+localStorage.getItem('token')
    },
    data: JSON.stringify({
      "Nº Serie":serie
    })
  }).done(function(resp){
    getBooks(); //actualizar listado de libros
  }).fail(function(error){
    //console.log(JSON.stringify(error));
    localStorage.removeItem('token');
    goTo("/");
  });
  return false;
}

/***********************************
      VISTAS Y RENDERIZACIÓN
************************************/
function loginPage(){
  content ='<h1>Login</h1><br/><div id="msg"></div><br/><form id="formLogin"><input type="text" name="username" placeholder="E-mail" id="username"><input type="password" name="password" id="password" placeholder="Contraseña"><button type="submit" value="Enviar" id="btnLogin">Enviar</button></form>';
  return content;
}

function signupPage(){
  content ='<h1>Registro</h1><br/><div id="msg"></div><br/><form id="formSignup"><input type="text" name="username" placeholder="E-mail" id="username"><input type="password" name="password" id="password" placeholder="Contraseña"><button type="submit" id="btnSignup">Enviar</button></form>';
  return content;
}
function confirmSignupPage(){
  content ='<h1>Confirmar e-mail</h1><br/><div id="msg"></div><br/><form id="formConfirmSignup"><input type="text" name="username" placeholder="E-mail" id="username"><input type="text" name="code" id="code" placeholder="Código"><button type="submit"  id="btnConfirmSignup">Enviar</button></form>';
  return content;
}

function  newPiezaPage(){
  content='<h1>Nuevo libro</h1><br/>';
  content+='<form id="formBook"><input type="text" name="pieza" placeholder="Pieza" id="pieza"><input type="text" name="serie" id="serie" placeholder="Serie"><button type="submit" value="Enviar" id="btnNewBook">Enviar</button></form>';
  return content;
}

function piezaPage(){
  content='<h1>Piezas</h1><br/><button id="linkNewPieza">Nueva pieza</button><br/>';
  content+='<table border="1"><tr><th>Pieza</th><th>Serie</th><th>Eliminar</th></tr>';
  for (i = 0; i< pieza.length; i++){
    content+='<tr><td>'+pieza[i].isbn+'</td><td>'+pieza[i].title+'</td><td><button id="isbn_'+pieza[i].isbn+'">X</button></td></tr>';
  }
  content+='</table>'
  return content;
}

function renderApp() {
  /* MENÚ */
  var li_pieza = document.getElementById('li_pieza');
  var li_login = document.getElementById('li_login');
  var li_logout = document.getElementById('li_logout');
  var li_signup = document.getElementById('li_signup');
  if (localStorage.getItem('token')===null){
    li_pieza.style.display = 'none';
    li_logout.style.display = 'none';
    li_login.style.display = 'block';
    li_signup.style.display = 'block';
  }else{
    li_pieza.style.display = 'block';
    li_logout.style.display = 'block';
    li_login.style.display = 'none';
    li_signup.style.display = 'none';
  }

/* CARGAR VISTAS */
  var content;
  if (window.location.pathname === '/taller') {
    content = booksPage();
  } else if (window.location.pathname === '/newpieza') {
    content = newpiezaPage();
  } else if (window.location.pathname === '/') {
    content = '<h1>¡Bienvenidos!</h1>';
  } else if(window.location.pathname === '/login'){
    content = loginPage();
  }else if(window.location.pathname === '/signup'){
    content = signupPage();
  }else if(window.location.pathname ==='/confirmsignup'){
    content=confirmSignupPage();
  }else if(window.location.pathname ==='/logout'){
    localStorage.removeItem('token');
    content = '<h1>¡Hasta pronto!</h1>';
    goTo("/");
  }
  var main = document.getElementsByTagName('main')[0];
  main.innerHTML = content;
}

/***********************************
             NAVEGACIÓN
************************************/
function navigate(evt) {
  evt.preventDefault();
  var href = evt.target.getAttribute('href');
  if(href==='/taller'){
    getBooks();
  }
  window.history.pushState({}, undefined, href);
  renderApp();
}

function goTo(path) {
  window.history.pushState({}, undefined, path);
  renderApp();
}

function newpieza(event){
  goTo('/newpieza');
}


/***********************************
          INICIALIZACIÓN
************************************/
$(document).ready(init);

function init(){
  $("nav").click(navigate);
  $("body").on("click","form button[id='btnLogin']",login);
  $("body").on("click","form button[id='btnSignup']",signup);
  $("body").on("click","form button[id='btnConfirmSignup']",confirmSignup);
  $("body").on("click","button[id^='serie']",deletePieza);
  $("body").on("click","button[id='linkNewPieza']",newpieza);
  $("body").on("click","form button[id='btnNewPieza']",putPieza);
  renderApp();
}